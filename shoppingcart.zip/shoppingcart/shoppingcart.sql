-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 27, 2013 at 04:40 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shoppingcart`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) DEFAULT NULL,
  `pid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `price` varchar(30) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` varchar(30) NOT NULL,
  KEY `pid` (`pid`,`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `pid`, `uid`, `pname`, `price`, `qty`, `total`) VALUES
(NULL, 5, 17, 'car', '180000', 1, '176400.0'),
(NULL, 10, 17, 'ring', '49000', 1, '47040.0');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(20) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cid`, `cname`) VALUES
(2, 'Automobiles'),
(3, 'Electronis & Compute'),
(4, 'Home Appliances'),
(5, 'Jewellery'),
(6, 'Mobiles & Cameras'),
(7, 'Toys & Gifts');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `Id` varchar(20) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Phone` varchar(30) NOT NULL,
  `Amount` varchar(30) NOT NULL,
  `Credit_no` varchar(30) NOT NULL,
  `Bank_name` varchar(30) NOT NULL,
  `Branch` varchar(30) NOT NULL,
  `Payment_date` date NOT NULL,
  PRIMARY KEY (`Credit_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Id`, `Name`, `Phone`, `Amount`, `Credit_no`, `Bank_name`, `Branch`, `Payment_date`) VALUES
('17', 'rosee', '988577777', '651000', '555555555555', 'Sbi bank', 'tarnaka', '2013-05-05'),
('17', 'rosee', '988577777', '684000', '667776788', 'Icici bank', 'shivamroad', '2013-05-06');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `pname` varchar(30) NOT NULL,
  `mrp` varchar(10) DEFAULT NULL,
  `discount` varchar(3) DEFAULT NULL,
  `imagename` varchar(300) DEFAULT NULL,
  `brand` varchar(20) DEFAULT NULL,
  `mfd` date DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `cid` (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `cid`, `pname`, `mrp`, `discount`, `imagename`, `brand`, `mfd`) VALUES
(5, 2, 'car', '180000', '2%', 'lgtv1.jpeg', 'honda city', '2009-04-01'),
(6, 2, 'bike', '500000', '4%', 'KRANTHI KUMAR.jpeg', 'honda', '2013-05-04'),
(7, 2, 'bike', '80000', '4%', 'laptop1.jpeg', 'pulser', '2013-05-04'),
(8, 5, 'chain', '340000', '3%', 'Koala.jpg', 'sant', '2013-05-05'),
(10, 5, 'ring', '49000', '4%', 'laptop1.jpeg', 'sant', '2013-05-05'),
(15, 2, 'hhh', '343', '2%', 'Rajini.jpg', 'df', '2013-05-07'),
(17, 2, 'sfasdf', '3434', '3%', 'Jellyfish.jpg', 'dfgdfgdg', '2013-05-08');

-- --------------------------------------------------------

--
-- Table structure for table `salesreport`
--

CREATE TABLE IF NOT EXISTS `salesreport` (
  `pid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `price` varchar(20) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` varchar(30) NOT NULL,
  KEY `pid` (`pid`,`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salesreport`
--

INSERT INTO `salesreport` (`pid`, `uid`, `pname`, `price`, `qty`, `total`) VALUES
(5, 17, 'car', '180000', 1, '171000.0'),
(6, 17, 'bike', '500000', 1, '480000.0'),
(5, 17, 'car', '180000', 1, '171000.0'),
(5, 17, 'car', '180000', 1, '171000.0'),
(5, 17, 'car', '180000', 2, '342000.0'),
(6, 17, 'bike', '500000', 1, '480000.0'),
(5, 17, 'car', '180000', 1, '171000.0'),
(6, 17, 'bike', '500000', 1, '480000.0'),
(5, 17, 'car', '180000', 1, '171000.0'),
(8, 17, 'chain', '340000', 1, '333200.0'),
(8, 17, 'chain', '340000', 1, '333200.0'),
(8, 17, 'chain', '340000', 1, '333200.0'),
(17, 17, 'sfasdf', '3434', 2, '6661.96');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(20) DEFAULT NULL,
  `uname` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `address` varchar(500) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `type` int(20) NOT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `fname`, `lname`, `uname`, `password`, `contact`, `address`, `email`, `dob`, `type`, `gender`, `status`) VALUES
(1, 'admin', 'adm', 'admin', 'admin123', '9885703834', 'hyderabad', 'santhoshk.coign@gmail.com', '1988-08-06', 0, 'M', 'accepted'),
(16, 'santhosh', 'k', 'santuu', 'santuu', '9885423652', 'hyd', 'sjdkfjsdk@lcom', '2013-05-02', 2, 'M', 'accepted'),
(17, 'rose', 'r', 'rosee', 'redred', '988577777', 'mncl', 'dsfsd#fsd.com', '2000-05-04', 1, 'F', 'accepted'),
(18, 'goldman', 'g', 'gold', '12345', '9887878787', 'hyd', 'san@fan.com', '1999-05-05', 5, 'M', 'accepted'),
(22, 'sdfsd', 'dsfsd', 'sdfsdf', '45454', '3434343', 'sfsdf', 'sdfs', '2013-05-08', 3, 'F', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `view_status`
--

CREATE TABLE IF NOT EXISTS `view_status` (
  `pid` int(20) NOT NULL,
  `image` varchar(200) NOT NULL,
  `count` int(20) NOT NULL DEFAULT '0',
  `utype` int(20) NOT NULL,
  `c_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `view_status`
--

INSERT INTO `view_status` (`pid`, `image`, `count`, `utype`, `c_date`) VALUES
(8, 'Koala.jpg', 4, 1, '2013-05-07 00:49:01'),
(6, 'KRANTHI KUMAR.jpeg', 1, 1, '2013-05-07 00:48:34'),
(5, 'lgtv1.jpeg', 3, 1, '2013-05-07 00:48:21'),
(17, 'Jellyfish.jpg', 1, 1, '2013-05-08 18:55:20'),
(10, 'laptop1.jpeg', 1, 1, '2013-05-08 19:38:49');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `products` (`pid`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `categories` (`cid`) ON DELETE CASCADE;

--
-- Constraints for table `salesreport`
--
ALTER TABLE `salesreport`
  ADD CONSTRAINT `salesreport_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `products` (`pid`);
